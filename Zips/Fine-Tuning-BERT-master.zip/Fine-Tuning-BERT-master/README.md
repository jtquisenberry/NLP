# Fine-Tuning BERT

BERT fine-tuned to perform spam classification.

Libraries used: PyTorch and Transformers
